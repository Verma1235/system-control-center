import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { logger } from '../utils/logger.js';
import argon2 from 'argon2';
import dotenv from "dotenv";
dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbDir = path.join(__dirname, '../../data');
let ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
let ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin";
// Ensure data directory exists
if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
}

const dbPath = path.join(dbDir, 'system_control.db');
const db = new Database(dbPath, { verbose: (msg) => logger.debug(msg) });

// Enable WAL mode for better concurrent performance
db.pragma('journal_mode = WAL');

// ============================================================
// SCHEMA DEFINITIONS
// ============================================================
function initDatabase() {
    logger.info("Initializing database schema...");

    // Administrators Table
    db.prepare(`
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at INTEGER NOT NULL
        )
    `).run();

    // Electron Nodes Table
    // Stores the public identity and connection parameters of a device.
    // Master Keys are NEVER stored on the server.
    db.prepare(`
        CREATE TABLE IF NOT EXISTS nodes (
            id TEXT PRIMARY KEY,
            hostname TEXT NOT NULL,
            platform TEXT NOT NULL,
            display_name TEXT,
            is_approved INTEGER DEFAULT 0,
            last_ip TEXT,
            last_seen INTEGER,
            capabilities TEXT, -- Stored as JSON string
            created_at INTEGER NOT NULL
        )
    `).run();

    // Audit Logs Table
    db.prepare(`
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT NOT NULL,
            node_id TEXT,
            user_id TEXT,
            details TEXT,
            ip_address TEXT,
            timestamp INTEGER NOT NULL
        )
    `).run();

    seedInitialAdmin();
    logger.info("Database initialization complete.");
}


// ============================================================
// SEEDING
// ============================================================
async function seedInitialAdmin() {
    // FIX: Check by the hardcoded ID rather than a hardcoded username string
    const existingAdmin = db.prepare(`SELECT id FROM users WHERE id = ?`).get('usr_default_admin');

    if (!existingAdmin) {
        logger.info(`No default admin found. Creating admin account: ${ADMIN_USERNAME}...`);
        try {
            const defaultPasswordHash = await argon2.hash(ADMIN_PASSWORD);

            db.prepare(`
                INSERT INTO users (id, username, password_hash, created_at)
                VALUES (?, ?, ?, ?)
            `).run('usr_default_admin', ADMIN_USERNAME, defaultPasswordHash, Date.now());

            logger.warn(`Default admin account created. Username: ${ADMIN_USERNAME}. PLEASE CHANGE THIS IMMEDIATELY.`);
        } catch (error) {
            logger.error("Failed to seed default admin", error);
        }
    }
}
initDatabase();

export { db };