import { db } from '../database/db.js';
import { logger } from '../utils/logger.js';
import { registerSignalingHandlers } from '../webrtc/signalingHandler.js';

export function handleNodeConnection(io, socket, activeDashboards) {
    const nodeId = socket.nodeId;
    const nodeData = db.prepare('SELECT * FROM nodes WHERE id = ?').get(nodeId);

    logger.info(`Node Connected: ${nodeData.hostname} (ID: ${nodeId})`);

    // Join the secure nodes room
    socket.join('electron-nodes');

    // Update DB status
    db.prepare('UPDATE nodes SET last_seen = ?, last_ip = ? WHERE id = ?').run(Date.now(), socket.handshake.address, nodeId);

    // Notify connected dashboards that a node came online
    io.to('dashboards').emit('node-status-changed', {
        nodeId,
        isOnline: true,
        lastSeen: Date.now()
    });

    // 1. WebRTC Signaling
    registerSignalingHandlers(socket, io);

    // 2. Encrypted Command Responses from Node -> Dashboard
    socket.on('command-response', (encryptedEnvelope) => {
        // The server relays the encrypted envelope directly to the dashboards.
        // Dashboards with the correct session key will decrypt it.
        io.to('dashboards').emit('command-response-relay', {
            nodeId,
            nodeSocketId: socket.id,
            envelope: encryptedEnvelope
        });
    });

    // 3. Telemetry / Health Updates (Unencrypted, non-sensitive metadata)
    socket.on('node-telemetry', (telemetryData) => {
        // e.g., CPU, RAM usage
        io.to('dashboards').emit('node-telemetry-update', {
            nodeId,
            telemetry: telemetryData
        });
    });

    // Disconnect Handler
    socket.on('disconnect', (reason) => {
        logger.info(`Node Disconnected: ${nodeData.hostname} (ID: ${nodeId}) - Reason: ${reason}`);

        db.prepare('UPDATE nodes SET last_seen = ? WHERE id = ?').run(Date.now(), nodeId);

        io.to('dashboards').emit('node-status-changed', {
            nodeId,
            isOnline: false,
            lastSeen: Date.now()
        });
    });
}