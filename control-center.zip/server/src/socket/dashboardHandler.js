import { logger } from '../utils/logger.js';
import { registerSignalingHandlers } from '../webrtc/signalingHandler.js';
import { db } from '../database/db.js';

export function handleDashboardConnection(io, socket, activeNodesMap) {
    logger.info(`Dashboard Connected: Admin User ${socket.user.username} (Socket: ${socket.id})`);

    // Join secure dashboard room
    socket.join('dashboards');

    // 1. WebRTC Signaling
    registerSignalingHandlers(socket, io);

    // 2. Command Dispatch (Dashboard -> Node)
    socket.on('dispatch-command', (data) => {
        const { targetNodeId, encryptedEnvelope } = data;

        // Verify the node is approved before allowing command dispatch
        const node = db.prepare('SELECT is_approved FROM nodes WHERE id = ?').get(targetNodeId);
        if (!node || node.is_approved === 0) {
            return socket.emit('command-error', {
                targetNodeId,
                error: 'NODE_UNAUTHORIZED',
                message: 'Target node is not approved or does not exist.'
            });
        }

        // Find the active socket ID for this node
        const nodeSocketId = activeNodesMap.get(targetNodeId);

        if (nodeSocketId) {
            // Relay the encrypted envelope to the target node
            io.to(nodeSocketId).emit('command-request', encryptedEnvelope);

            logger.audit(`Command dispatched to node ${targetNodeId}`, { admin: socket.user.username });
        } else {
            socket.emit('command-error', {
                targetNodeId,
                error: 'NODE_OFFLINE',
                message: 'Target node is currently offline.'
            });
        }
    });

    socket.on('disconnect', () => {
        logger.info(`Dashboard Disconnected: ${socket.user.username}`);
    });
}