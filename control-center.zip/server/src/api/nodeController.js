
import { db } from '../database/db.js';
import { logger } from '../utils/logger.js';
import { getActiveNodesMap } from '../socket/socketManager.js'; // ✨ Import active nodes map

export const nodeController = {
    /**
     * Get all registered nodes with their capabilities and status
     */
    getAllNodes: (req, res) => {
        try {
            const nodes = db.prepare('SELECT * FROM nodes ORDER BY last_seen DESC').all();
            const activeNodes = getActiveNodesMap(); // ✨ Get current active socket connections

            // Parse JSON capabilities and attach real-time online status
            const parsedNodes = nodes.map(node => ({
                ...node,
                isOnline: activeNodes.has(node.id), // ✨ Real-time check from socket memory map
                is_approved: Boolean(node.is_approved),
                capabilities: node.capabilities ? JSON.parse(node.capabilities) : {}
            }));

            return res.json({
                success: true,
                nodes: parsedNodes
            });
        } catch (error) {
            logger.error("Error fetching nodes list", { error: error.message });
            return res.status(500).json({
                success: false,
                error: "INTERNAL_ERROR",
                message: "Could not retrieve devices."
            });
        }
    },
    getNodeById: (req, res) => {
        try {
            const { id } = req.params;
            const node = db.prepare('SELECT * FROM nodes WHERE id = ?').get(id);

            if (!node) {
                return res.status(404).json({
                    success: false,
                    error: "NODE_NOT_FOUND",
                    message: "Node does not exist."
                });
            }

            return res.json({
                success: true,
                node: {
                    ...node,
                    is_approved: Boolean(node.is_approved),
                    capabilities: node.capabilities ? JSON.parse(node.capabilities) : {}
                }
            });
        } catch (error) {
            logger.error("Error fetching single node", { error: error.message });
            return res.status(500).json({
                success: false,
                error: "INTERNAL_ERROR",
                message: "Failed to retrieve node."
            });
        }
    },

    /**
     * Approve or Revoke a node's authorized state
     */
    /**
       * Approve or Revoke a node's authorized state
       */
    toggleApproval: (req, res) => {
        try {
            const { id } = req.params;
            const { approved } = req.body;

            const node = db.prepare('SELECT * FROM nodes WHERE id = ?').get(id);
            if (!node) {
                return res.status(404).json({
                    success: false,
                    error: "NODE_NOT_FOUND",
                    message: "Node does not exist."
                });
            }

            const approvalState = approved ? 1 : 0;
            db.prepare('UPDATE nodes SET is_approved = ? WHERE id = ?').run(approvalState, id);

            const actionName = approved ? 'APPROVE_NODE' : 'REVOKE_NODE';
            logger.audit(`Node authorization toggled: ${id} -> ${approved}`, { adminId: req.user.sub });

            // FIX: Added the 6th '?' placeholder to match the 6 columns
            db.prepare(`
                INSERT INTO audit_logs (action, node_id, user_id, details, ip_address, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            `).run(actionName, id, req.user.sub, `Approval changed to ${approved}`, req.ip, Date.now());

            return res.json({
                success: true,
                message: `Node ${approved ? 'approved' : 'revoked'} successfully.`
            });
        } catch (error) {
            logger.error("Error toggling node authorization", { error: error.message });
            return res.status(500).json({
                success: false,
                error: "INTERNAL_ERROR",
                message: "Could not alter node authorization state."
            });
        }
    },

    /**
     * Delete a registered node from database
     */
    deleteNode: (req, res) => {
        try {
            const { id } = req.params;
            db.prepare('DELETE FROM nodes WHERE id = ?').run(id);

            logger.audit(`Node deleted from registry: ${id}`, { adminId: req.user.sub });

            // FIX: Added the 6th '?' placeholder here as well
            db.prepare(`
                INSERT INTO audit_logs (action, node_id, user_id, details, ip_address, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            `).run('DELETE_NODE', id, req.user.sub, `Node registry deleted`, req.ip, Date.now());

            return res.json({
                success: true,
                message: "Node record deleted successfully."
            });
        } catch (error) {
            logger.error("Error deleting node", { error: error.message });
            return res.status(500).json({
                success: false,
                error: "INTERNAL_ERROR",
                message: "Could not delete node record."
            });
        }
    },

    /**
     * Retrieve audit log history
     */
    getAuditLogs: (req, res) => {
        try {
            const limit = Math.min(parseInt(req.query.limit || '50', 10), 200);
            const logs = db.prepare('SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT ?').all(limit);

            return res.json({
                success: true,
                logs
            });
        } catch (error) {
            logger.error("Error fetching audit logs", { error: error.message });
            return res.status(500).json({
                success: false,
                error: "INTERNAL_ERROR",
                message: "Could not retrieve audit history."
            });
        }
    }
    // ... baaki getNodeById, toggleApproval, deleteNode, getAuditLogs functions wese hi rahenge ...
};