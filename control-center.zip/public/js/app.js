import { state } from './core/state.js';
import { api } from './core/api.js';
import { LogsUI } from './ui/logs.js';
import { DashboardUI } from './ui/dashboard.js';
import { SocketManager } from './socket/socketClient.js';

document.addEventListener("DOMContentLoaded", () => {

    // UI Elements
    const authModal = document.getElementById("authModal");
    const authForm = document.getElementById("authForm");
    const authError = document.getElementById("authError");
    const usernameInput = document.getElementById("adminUsernameInput");
    const passwordInput = document.getElementById("adminPasswordInput");
    const lockSessionBtn = document.getElementById("lockSessionBtn");

    // Initialize modules
    LogsUI.init();
    DashboardUI.init();

    const bootApplication = async () => {
        try {
            // Verify token is still valid on backend
            await api.verifySession();

            // Hide modal
            authModal.classList.add("hidden");

            // Log success
            LogsUI.add({ message: "Dashboard unlocked and authenticated.", type: "success", source: "AUTH" });

            // Load initial data
            const data = await api.getNodes();
            DashboardUI.render(data.nodes);

            // Connect Real-Time Socket
            SocketManager.connect();

        } catch (error) {
            // Token invalid or expired
            state.set('token', null);
            authModal.classList.remove("hidden");
        }
    };

    // Form Submission
    authForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const username = usernameInput.value.trim();
        const password = passwordInput.value.trim();
        authError.classList.add("hidden");

        try {
            const res = await api.login(username, password);
            if (res.success) {
                state.set('token', res.token);
                state.set('user', res.user);

                // Clear inputs
                passwordInput.value = "";

                await bootApplication();
            }
        } catch (err) {
            authError.textContent = err.message || "Authentication failed.";
            authError.classList.remove("hidden");
        }
    });

    // Lock Session
    lockSessionBtn?.addEventListener("click", () => {
        state.set('token', null);
        SocketManager.disconnect();
        window.location.reload();
    });

    // Startup Logic
    if (state.get('token')) {
        bootApplication();
    } else {
        authModal.classList.remove("hidden");
    }
});