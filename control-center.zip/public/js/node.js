import { state } from './core/state.js';
import { api } from './core/api.js';
import { SocketManager } from './socket/socketClient.js';
import { WebRTCManager } from './webrtc/rtcManager.js';
import { encryptPayload, decryptPayload } from './core/crypto.js';
import { LogsUI } from './ui/logs.js';

const PROVISIONING_SECRET = 'setup_secret_key_123';

document.addEventListener("DOMContentLoaded", async () => {
    LogsUI.init();

    const urlParams = new URLSearchParams(window.location.search);
    const targetNodeId = urlParams.get('id');

    if (!targetNodeId) {
        alert("No Node ID specified.");
        window.location.href = '/index.html';
        return;
    }

    try {
        const res = await api.getNodeById(targetNodeId);
        document.getElementById('nodeHostname').textContent = `${res.node.hostname} (${res.node.platform})`;
    } catch (e) {
        alert("Failed to load node: " + e.message);
        window.location.href = '/index.html';
        return;
    }

    SocketManager.connect();
    const socket = SocketManager.get();
    const rtcManager = new WebRTCManager(SocketManager, targetNodeId);

    const encoder = new TextEncoder();
    const keyData = encoder.encode(PROVISIONING_SECRET);
    const sessionKeyBuffer = await window.crypto.subtle.digest('SHA-256', keyData);

    window.dispatchE2ECommand = async function (type, payloadData = {}) {
        const currentSocket = SocketManager.get();
        if (!currentSocket || !currentSocket.connected) {
            alert("Socket is disconnected. Cannot dispatch command.");
            return;
        }

        const payloadString = JSON.stringify({
            commandId: crypto.randomUUID(),
            type: type,
            payload: payloadData
        });

        try {
            const encryptedEnvelope = await encryptPayload(payloadString, sessionKeyBuffer, "dashboard-admin");
            currentSocket.emit('dispatch-command', { targetNodeId, encryptedEnvelope });
            LogsUI.add({ message: `Dispatched encrypted command: ${type}`, type: "info", source: "COMMAND" });
        } catch (err) {
            LogsUI.add({ message: `Encryption failed: ${err.message}`, type: "error", source: "CRYPTO" });
        }
    };

    socket.on('command-response-relay', async (data) => {
        if (data.nodeId !== targetNodeId) return;

        try {
            const decryptedString = await decryptPayload(data.envelope, sessionKeyBuffer);
            const response = JSON.parse(decryptedString);

            if (response.success) {
                LogsUI.add({ message: `Success: ${response.status}`, type: "success", source: "NODE" });

                if (response.data && typeof response.data.items !== 'undefined') {
                    renderFileTree(response.data);
                }
                // Agar file content read hua hai toh editor modal me kholen
                if (response.data && typeof response.data.content !== 'undefined') {
                    openFileEditor(window.activeEditingPath, response.data.content);
                }
            } else {
                LogsUI.add({ message: `Failed: ${response.error}`, type: "error", source: "NODE" });
            }
        } catch (err) {
            LogsUI.add({ message: `Decryption failed: ${err.message}`, type: "error", source: "SECURITY" });
        }
    });

    socket.on('node-status-changed', (data) => {
        if (data.nodeId === targetNodeId) {
            const badge = document.getElementById('nodeStatusBadge');
            if (!badge) return;
            if (data.isOnline) {
                badge.className = "inline-flex items-center gap-1.5 py-1 px-2.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
                badge.innerHTML = `<i class="fa-solid fa-wifi"></i> Online`;
            } else {
                badge.className = "inline-flex items-center gap-1.5 py-1 px-2.5 rounded-full text-[9px] font-bold uppercase tracking-wider bg-rose-500/10 text-rose-400 border border-rose-500/20";
                badge.innerHTML = `<i class="fa-solid fa-link-slash"></i> Offline`;
                rtcManager.close();
            }
        }
    });

    const bindClick = (id, handler) => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('click', handler);
    };

    // Media Controls
    bindClick('btnStartScreen', async () => { await rtcManager.createPeerConnection(); window.dispatchE2ECommand('start_screen'); });
    bindClick('btnStopScreen', () => { window.dispatchE2ECommand('stop_screen'); });

    // Power Controls
    bindClick('btnLock', () => { if (confirm("Lock remote OS?")) window.dispatchE2ECommand('lock_screen'); });
    bindClick('btnRestart', () => { if (confirm("Restart remote OS?")) window.dispatchE2ECommand('restart'); });
    bindClick('btnShutdown', () => { if (confirm("Shutdown remote OS?")) window.dispatchE2ECommand('shutdown'); });

    // File Explorer & Editor Logic
    let currentRemotePath = 'root';
    window.activeEditingPath = null;

    window.navigateToDir = (path) => window.dispatchE2ECommand('get_dir_tree', { path });
    window.deleteRemoteItem = (path) => { if (confirm(`Delete ${path}?`)) { window.dispatchE2ECommand('delete_item', { path }); setTimeout(() => window.navigateToDir(currentRemotePath), 800); } };
    window.openFile = (path) => { window.activeEditingPath = path; window.dispatchE2ECommand('read_file', { path }); };

    bindClick('btnRefreshFiles', () => window.navigateToDir('root'));

    bindClick('btnNewFolder', () => {
        const folderName = prompt("Enter new folder name:");
        if (folderName && currentRemotePath !== 'root') {
            const newPath = currentRemotePath.endsWith('/') || currentRemotePath.endsWith('\\') ? currentRemotePath + folderName : currentRemotePath + '/' + folderName;
            window.dispatchE2ECommand('create_folder', { path: newPath });
            setTimeout(() => window.navigateToDir(currentRemotePath), 800);
        } else {
            alert("Please navigate inside a valid drive/folder first.");
        }
    });

    bindClick('btnNewFile', () => {
        const fileName = prompt("Enter new file name (e.g. note.txt):");
        if (fileName && currentRemotePath !== 'root') {
            const newPath = currentRemotePath.endsWith('/') || currentRemotePath.endsWith('\\') ? currentRemotePath + fileName : currentRemotePath + '/' + fileName;
            window.activeEditingPath = newPath;
            openFileEditor(newPath, "");
        } else {
            alert("Please navigate inside a valid drive/folder first.");
        }
    });

    // Modal Controls
    const modal = document.getElementById('fileEditorModal');
    const textarea = document.getElementById('fileContentInput');

    function openFileEditor(filePath, content) {
        document.getElementById('editingFileName').textContent = filePath;
        textarea.value = content;
        modal.classList.remove('hidden');
    }

    bindClick('btnCloseModal', () => modal.classList.add('hidden'));
    bindClick('btnCancelEdit', () => modal.classList.add('hidden'));
    bindClick('btnSaveFile', () => {
        if (window.activeEditingPath) {
            window.dispatchE2ECommand('save_file', { path: window.activeEditingPath, content: textarea.value });
            modal.classList.add('hidden');
            LogsUI.add({ message: `Saved file: ${window.activeEditingPath}`, type: "success" });
        }
    });

    function renderFileTree(data) {
        currentRemotePath = data.currentPath;
        const pathText = document.getElementById('currentPathText');
        if (pathText) pathText.textContent = data.currentPath;

        const container = document.getElementById('filesContainer');
        if (!container) return;
        container.innerHTML = '';

        if (data.currentPath !== 'root') {
            const parentDir = data.currentPath.substring(0, data.currentPath.lastIndexOf('\\')) || data.currentPath.substring(0, data.currentPath.lastIndexOf('/')) || 'root';
            container.innerHTML += `
                <div class="flex items-center gap-2 p-2 hover:bg-slate-800/50 rounded cursor-pointer transition text-slate-300" onclick="window.navigateToDir('${parentDir.replace(/\\/g, '\\\\')}')">
                    <i class="fa-solid fa-level-up-alt text-indigo-400 w-4"></i>
                    <span class="text-[10px] font-bold">.. (Up)</span>
                </div>
            `;
        }

        data.items.forEach(item => {
            const icon = item.isDirectory ? '<i class="fa-solid fa-folder text-amber-400"></i>' : '<i class="fa-solid fa-file text-slate-400"></i>';
            const escapedPath = item.path.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            const clickAction = item.isDirectory ? `window.navigateToDir('${escapedPath}')` : `window.openFile('${escapedPath}')`;

            container.innerHTML += `
                <div class="flex items-center justify-between p-2 hover:bg-slate-800/50 rounded transition group">
                    <div class="flex items-center gap-2 flex-1 min-w-0 cursor-pointer text-slate-300" onclick="${clickAction}">
                        <div class="w-4 text-center">${icon}</div>
                        <span class="text-[10px] font-medium truncate group-hover:text-white" title="${item.name}">${item.name}</span>
                    </div>
                    <div class="opacity-0 group-hover:opacity-100 transition flex gap-1">
                        <button class="h-5 w-5 rounded bg-rose-900/30 text-rose-400 hover:bg-rose-900 hover:text-white flex items-center justify-center transition" onclick="window.deleteRemoteItem('${escapedPath}')">
                            <i class="fa-solid fa-trash text-[8px]"></i>
                        </button>
                    </div>
                </div>
            `;
        });
    }

    setTimeout(() => window.navigateToDir('root'), 1000);
});